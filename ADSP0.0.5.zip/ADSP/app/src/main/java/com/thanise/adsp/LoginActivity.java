package com.thanise.adsp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;


import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
//MAIN!!!!

public class LoginActivity extends AppCompatActivity {
    EditText email, senha;
    Button botaoCadastro;
    Button botaoEntrar;
    TextView texto1;

    FirebaseDatabase firebaseDatabase;
    DatabaseReference databaseReference;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        setTitle("Login");

        email = (EditText) findViewById(R.id.email);
        senha = (EditText) findViewById(R.id.senha);
        botaoCadastro = (Button) findViewById(R.id.botaoCadastro);
        botaoEntrar = (Button) findViewById(R.id.botaoEntrar);
        texto1 = (TextView)findViewById(R.id.texto1) ;

        texto1.setText("");

        botaoEntrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
            if(email.getText().toString().equals("") && senha.getText().toString().equals("")){
                    texto1.setText("Os campos precisam ser preenchidos");

                }
                else if (email.getText().toString().equals("") || senha.getText().toString().equals("")){
                    texto1.setText("Ambos os campos precisam ser preenchidos");

                }
                else if(email.getText().toString().equals("thanise@gmail.com") && senha.getText().toString().equals("12345678")) {
                    Intent intent2 = new Intent(getBaseContext(), TelaInicialActivity.class);
                    startActivity(intent2);
                    finish();
                }
                else {
                    texto1.setText("O email e/ou a senha estão incorretos" );

                }

            }
        });

        botaoCadastro.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent= new Intent(getBaseContext(), CadastroActivity.class);
                startActivity(intent);
            }
        });

        inicializarFirebase();

       //databaseReference.child("oi").setValue("ois");

    }

    private void inicializarFirebase() {
        firebaseDatabase = FirebaseDatabase.getInstance();
        databaseReference = firebaseDatabase.getReference();
    }


}
