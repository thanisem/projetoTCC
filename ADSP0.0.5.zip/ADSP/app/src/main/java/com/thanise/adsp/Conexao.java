package com.thanise.adsp;

public class Conexao {
// private static FirebaseAuth firebaseAuth;
}
