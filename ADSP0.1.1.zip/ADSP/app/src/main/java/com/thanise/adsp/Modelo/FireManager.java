package com.thanise.adsp.Modelo;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class FireManager {
    private static DatabaseReference referenciaBD;
    private static FirebaseAuth authFB;

    public static DatabaseReference getReferenciaBD(){
        if(referenciaBD==null){
            referenciaBD = FirebaseDatabase.getInstance().getReference();
        }
        return referenciaBD;
    }
    public static FirebaseAuth getAuthFB(){
        if (authFB ==null){
            authFB = FirebaseAuth.getInstance();
        }
        return authFB;
    }
}
