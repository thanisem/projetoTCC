package com.thanise.adsp.Modelo;
import com.google.firebase.database.Exclude;

import java.util.HashMap;
import java.util.Map;

public class Alarme {
    private String id;
    private String hora, minutos;
    private Boolean segunda, terca, quarta, quinta, sexta, sabado, domingo;
    private String nome;
    private Boolean status;


    public Alarme(){


    }
    public Alarme(String id, String hora, String minutos, Boolean status){
        this.hora = hora;
        this.id = id;
        this.status = status;
        this.minutos = minutos;

    }

    @Override
    public String toString() {
        return "Alarme{" +
                "id='" + id + '\'' +
                ", hora='" + hora + '\'' +
                ", segunda=" + segunda +
                ", terca=" + terca +
                ", quarta=" + quarta +
                ", quinta=" + quinta +
                ", sexta=" + sexta +
                ", sabado=" + sabado +
                ", domingo=" + domingo +
                ", minutos=" + minutos +
                ", nome='" + nome + '\'' +
                ", status=" + status +
                '}';
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getHora() {
        return hora;
    }

    public void setHora(String hora) {
        this.hora = hora;
    }

    public Boolean getSegunda() {
        return segunda;
    }

    public void setSegunda(Boolean segunda) {
        this.segunda = segunda;
    }

    public Boolean getTerca() {
        return terca;
    }

    public void setTerca(Boolean terca) {
        this.terca = terca;
    }

    public Boolean getQuarta() {
        return quarta;
    }

    public void setQuarta(Boolean quarta) {
        this.quarta = quarta;
    }

    public Boolean getQuinta() {
        return quinta;
    }

    public void setQuinta(Boolean quinta) {
        this.quinta = quinta;
    }

    public Boolean getSexta() {
        return sexta;
    }

    public void setSexta(Boolean sexta) {
        this.sexta = sexta;
    }

    public Boolean getSabado() {
        return sabado;
    }

    public void setSabado(Boolean sabado) {
        this.sabado = sabado;
    }

    public Boolean getDomingo() {
        return domingo;
    }

    public void setDomingo(Boolean domingo) {
        this.domingo = domingo;
    }

    public String getMinutos() {
        return minutos;
    }

    public void setMinutos(String minutos) {
        this.minutos = minutos;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public Boolean getStatus() {
        return status;
    }

    public void setStatus(Boolean status) {
        this.status = status;
    }
    @Exclude
    public Map<String, Object> toMap(){
        HashMap<String, Object> hashMapAlarme = new HashMap<>();

        hashMapAlarme.put("id", getId());
        hashMapAlarme.put("nome", getNome());
        hashMapAlarme.put("hora", getHora());
        hashMapAlarme.put("minutos", getMinutos());
        hashMapAlarme.put("status", getStatus());
        hashMapAlarme.put("segunda", getSegunda());
        hashMapAlarme.put("terça", getTerca());
        hashMapAlarme.put("quarta", getQuarta());
        hashMapAlarme.put("quinta", getQuinta());
        hashMapAlarme.put("sexta", getSexta());
        hashMapAlarme.put("sabado", getSabado());
        hashMapAlarme.put("domingo", getDomingo());

        return hashMapAlarme;
    }
}
