package com.thanise.adsp.Activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException;
import com.google.firebase.auth.FirebaseAuthUserCollisionException;
import com.google.firebase.auth.FirebaseAuthWeakPasswordException;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.UserProfileChangeRequest;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.thanise.adsp.Modelo.Usuario;
import com.thanise.adsp.R;

public class CadastroActivity extends AppCompatActivity {
    private FirebaseAuth mAuth;
    EditText editemail, editpassword, editname, editphone, editc;
    Button botaoCadastrar;
    public Usuario usuario;
    public ProgressBar carregando;


    private static final String TAG = "MainActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastro);

        carregando = (ProgressBar)findViewById(R.id.carregando);
        carregando.setVisibility(View.INVISIBLE);


        editemail = (EditText) findViewById(R.id.editemail);
        editpassword = (EditText) findViewById(R.id.editpassword);
        editc = (EditText) findViewById(R.id.editc);
        editname = (EditText) findViewById(R.id.editname);
        editphone = (EditText) findViewById(R.id.editphone);
        botaoCadastrar = (Button)findViewById(R.id.botaoCadastrar);
        botaoCadastrar.setOnClickListener(new View.OnClickListener()

        {
            @Override
            public void onClick(View v) {
                if(editpassword.getText().toString().equals(editc.getText().toString())){
                    if (editname.getText().toString().isEmpty() ||
                            editphone.getText().toString().isEmpty() ||
                            editemail.getText().toString().isEmpty() ||
                            editc.getText().toString().isEmpty() ||
                            editpassword.getText().toString().isEmpty()){
                        Toast.makeText(CadastroActivity.this, "Todos os campos devem ser preenchidos!", Toast.LENGTH_SHORT).show();
                    }
                    else {
                        usuario = new Usuario();
                        usuario.setNome(editname.getText().toString());
                        usuario.setEmail(editemail.getText().toString());
                        usuario.setTelefone(editphone.getText().toString());
                        usuario.setSenha(editpassword.getText().toString());

                        carregando.setIndeterminate(true);
                        carregando.setVisibility(View.VISIBLE);

                        Cadastro();

                    }

                }
                else{ Toast.makeText(CadastroActivity.this, "As senhas precisam ser iguais!", Toast.LENGTH_LONG).show();

                }

            }

        });

        mAuth = FirebaseAuth.getInstance();
        setTitle("Cadastro");



    }
    public void Cadastro(){
        mAuth.createUserWithEmailAndPassword(usuario.getEmail(), usuario.getSenha()).addOnCompleteListener(CadastroActivity.this, new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if(task.isSuccessful()){
                    FirebaseUser user= task.getResult().getUser();
                    usuario.setId(mAuth.getUid());
                    UserProfileChangeRequest UpdateName = new UserProfileChangeRequest.Builder().setDisplayName(usuario.getNome()).build();
                    user.updateProfile(UpdateName);
                    usuario.salvar();

                    Logar();
                }
                else{
                    String erroExcecao = "";
                    try {
                        throw task.getException();
                    }
                    catch (FirebaseAuthWeakPasswordException e){
                        erroExcecao = "Digite uma senha mais forte";
                    }
                    catch (FirebaseAuthInvalidCredentialsException e){
                        erroExcecao = "O email é inválido";
                    }
                    catch (FirebaseAuthUserCollisionException e){
                        erroExcecao= "Este email já está cadastrado";
                    }
                    catch (Exception e){
                        erroExcecao = "Erro ao efetuar o cadastro, verifique sua conexão";
                        e.printStackTrace();
                    }
                    Toast.makeText(CadastroActivity.this, erroExcecao, Toast.LENGTH_SHORT).show();
                    carregando.setVisibility(View.INVISIBLE);
                }
            }
        });



    }

    public void Logar(){
        Intent intent = new Intent(CadastroActivity.this, LoginActivity.class);
        startActivity(intent);
        finish();
    }
}
