package com.thanise.adsp.Activity;
import android.bluetooth.BluetoothAdapter;
import androidx.appcompat.app.AppCompatActivity;

import android.bluetooth.BluetoothAdapter;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.thanise.adsp.R;

public class BluetoothActivity extends AppCompatActivity {
    BluetoothAdapter meuBluetoothAdapter = null;
    private static final int solicita_bluetooth = 1;
    Button conectabluetooth;
    private Button configuracoesbluetooth;
    boolean conexao;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bluetooth);
        conectabluetooth = (Button) findViewById(R.id.conectabluetooth);


        meuBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();

        if (meuBluetoothAdapter == null) {
            Toast.makeText(this.getBaseContext(), "Seu dispositivo não tem bluetooth", Toast.LENGTH_LONG).show();
        } else if (meuBluetoothAdapter.isEnabled()) {
            Intent Solicita_Bluetooth = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
            startActivityForResult(Solicita_Bluetooth, solicita_bluetooth);

        }
        conectabluetooth.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (conexao){

                }
                else {

                }
            }
        });
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data){
        switch (requestCode){
            case solicita_bluetooth:
                if (resultCode == BluetoothActivity.RESULT_OK ){
                Toast.makeText(this.getBaseContext(), "Seu dispositivo bluetooth foi ativado", Toast.LENGTH_LONG).show();

            }
            else {
                Toast.makeText(this.getBaseContext(), "O bluetooth, não foi ativado", Toast.LENGTH_LONG).show();
            }
        }
    }


}

