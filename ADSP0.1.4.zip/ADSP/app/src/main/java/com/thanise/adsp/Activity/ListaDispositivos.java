package com.thanise.adsp.Activity;

import android.app.ListActivity;
import android.os.Bundle;



public class ListaDispositivos extends ListActivity {

    @Override
    protected void onCreate( Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        //TODO parte 3 video aula
    }
}
