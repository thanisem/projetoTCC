package com.thanise.adsp.Activity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Switch;

import com.thanise.adsp.Modelo.Alarme;
import com.thanise.adsp.R;

public class NovoAlarme extends AppCompatActivity {
    EditText hora, minutos;
    Button salvaralarme;
    Switch ativaralarme;
    EditText nomealarme;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_novo_alarme);

        hora =(EditText)findViewById(R.id.edithora);
        minutos=(EditText)findViewById(R.id.editminutos);
        nomealarme=(EditText)findViewById(R.id.editnomea);
        ativaralarme=(Switch)findViewById(R.id.ativaralarme);
        salvaralarme=(Button)findViewById(R.id.salvaralarme);

        salvaralarme.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });
    }
    private void CriarNovoAlarme(String id, String hora, String minutos, Boolean ativaralarme){
        Alarme alarme = new Alarme(id, hora, minutos, ativaralarme);
        //TODO terminar aqui


    }

}
