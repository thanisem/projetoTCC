package com.thanise.adsp.Activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import android.net.Uri;
import android.os.Bundle;
import android.view.MenuItem;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.thanise.adsp.Fragments.AlarmeFragment;
import com.thanise.adsp.Fragments.CalendarioFragment;
import com.thanise.adsp.Fragments.ConfiguracoesFragment;
import com.thanise.adsp.Fragments.OximetroFragment;
import com.thanise.adsp.R;

public class TelaInicialActivity extends AppCompatActivity implements
        BottomNavigationView.OnNavigationItemSelectedListener,
        AlarmeFragment.OnFragmentInteractionListener,
        CalendarioFragment.OnFragmentInteractionListener,
        ConfiguracoesFragment.OnFragmentInteractionListener,
        OximetroFragment.OnFragmentInteractionListener{

    FirebaseDatabase firebaseDatabase;
    DatabaseReference databaseReference;
    private FirebaseAuth mAuth;
    public FirebaseUser usuarioatual = FirebaseAuth.getInstance().getCurrentUser();
    private BottomNavigationView navigationView;
    String st1 = "a", st2 = "b";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_inicial);

        navigationView = (BottomNavigationView)findViewById(R.id.navigationview);
        navigationView.setOnNavigationItemSelectedListener(this);

        setTitle("Calendário");
        Fragment calendarioFragment = CalendarioFragment.newInstance(st1, st2);
        openFragment(calendarioFragment);
    }


    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
        switch (menuItem.getItemId()){
            case R.id.nalarme:{
                setTitle("Alarme");
                Fragment alarmeFragment = AlarmeFragment.newInstance(st1, st2);
                        openFragment(alarmeFragment);
                break;
            }
            case R.id.ncalendario:{
                setTitle("Calendário");
                Fragment calendarioFragment = CalendarioFragment.newInstance(st1, st2);
                openFragment(calendarioFragment);
                break;
            }
            case R.id.nconfiguracoes:{
                setTitle("Configurações");
                Fragment configuracoesFragment = ConfiguracoesFragment.newInstance(st1, st2);
                openFragment(configuracoesFragment);
                break;
            }
            case R.id.noximetro:{
                setTitle("Oxímetro");
                Fragment oximetroFragment = OximetroFragment.newInstance(st1, st2);
                openFragment(oximetroFragment);
                break;
            }

        }
        return true;

    }
    private void openFragment(Fragment fragment){
        FragmentTransaction transaction= getSupportFragmentManager().beginTransaction();
        transaction.replace(R.id.container, fragment);
        transaction.addToBackStack(null);
        transaction.commit();
    }

    @Override
    public void onFragmentInteraction(Uri uri){

    }
}
