package com.thanise.adsp.Activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;


import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.thanise.adsp.R;
//MAIN!!!!

public class LoginActivity extends AppCompatActivity {
    EditText email, senha;
    Button botaoCadastro;
    Button botaoEntrar;
    TextView texto1;
    ProgressBar carregando2;

    FirebaseDatabase firebaseDatabase;
    DatabaseReference databaseReference;
    private FirebaseAuth mAuth;
    private FirebaseAuth.AuthStateListener authStateListener;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        mAuth = FirebaseAuth.getInstance();

        carregando2 = (ProgressBar)findViewById(R.id.carregando2);
        carregando2.setVisibility(View.INVISIBLE);

        setTitle("Login");

        email = (EditText) findViewById(R.id.editemail);
        senha = (EditText) findViewById(R.id.editsenha);
        botaoCadastro = (Button) findViewById(R.id.botaoCadastro);
        botaoEntrar = (Button) findViewById(R.id.botaoEntrar);
        carregando2 = (ProgressBar)findViewById(R.id.carregando2);
        texto1 = (TextView)findViewById(R.id.texto1) ;

        texto1.setText("");

        botaoEntrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                carregando2.setVisibility(View.VISIBLE);

           Iniciar(email.getText().toString(),senha.getText().toString());

            }
        });

        botaoCadastro.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent= new Intent(getBaseContext(), CadastroActivity.class);
                startActivity(intent);
            }
        });

        inicializarFirebase();

       //databaseReference.child("oi").setValue("ois");

    }

    private void inicializarFirebase() {
        firebaseDatabase = FirebaseDatabase.getInstance();
        databaseReference = firebaseDatabase.getReference();
    }
    @Override
    public void onStart() {

        super.onStart();
        // Check if user is signed in (non-null) and update UI accordingly.
        FirebaseUser currentUser = mAuth.getCurrentUser();

    }

    public void Iniciar(String email, String password){

        mAuth.signInWithEmailAndPassword(email, password).addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            // Sign in success, update UI with the signed-in user's information
                            FirebaseUser user = mAuth.getCurrentUser();

                            Intent intent2= new Intent(getBaseContext(), TelaInicialActivity.class);
                            startActivity(intent2);
                            finish();
                        } else {
                            // If sign in fails, display a message to the user.
                            //*Log.w(TAG, "signInWithEmail:failure", task.getException());
                            Toast.makeText(LoginActivity.this, "Falha ao fazer login", Toast.LENGTH_SHORT).show();

                            carregando2.setVisibility(View.INVISIBLE);
                        }

                        // ...
                    }
                });
    }

}
