package com.thanise.adsp.Activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.thanise.adsp.R;

import java.util.HashMap;
import java.util.Map;

public class CalendarioEventoActivity extends AppCompatActivity {
    TextView dataSel;
    EditText nomee, horae, notae;
    String id;
    Button salvarevento, cancelarevento;
    Evento evento = new Evento();


    FirebaseDatabase firebaseDatabase;
    DatabaseReference databaseReference;
    private FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
    private DatabaseReference firebase = FirebaseDatabase.getInstance().getReference("usuario").child(user.getUid()).child("eventos");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calendario_evento);

        final FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        String uid = user.getUid();

         dataSel= (TextView)findViewById(R.id.dataSel);
         nomee= (EditText)findViewById(R.id.nomeEvento);
         horae= (EditText)findViewById(R.id.horadoEvento);
        notae= (EditText)findViewById(R.id.notae);
        salvarevento= (Button)findViewById(R.id.salvarevento);
        cancelarevento= (Button)findViewById(R.id.cancelarevento);

        Intent recebe_evento = getIntent();
        Bundle r = recebe_evento.getExtras();

        if (r!= null){
            String resultadofinal=(String) r.get("data");
            dataSel.setText(resultadofinal);
        }

        salvarevento.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                evento = new Evento();
                evento.setNomeEvento(nomee.getText().toString());
                evento.setDataEvento(dataSel.getText().toString());
                evento.setHoraEvento(horae.getText().toString());
                evento.setNotaEvento(notae.getText().toString());
                String key = firebase.push().getKey();
                newEvento(nomee.getText().toString(), dataSel.getText().toString(), horae.getText().toString(), notae.getText().toString(),key);

            }
        });


    }
    private void newEvento(String n, String d, String h, String nota, String id) {

        Evento evento = new Evento(n, d, h, nota, id);
        Map<String, Object> InterValues = evento.toMap();
        Map<String, Object> InterUpdates = new HashMap<>();
        InterUpdates.put(id, InterValues);
        firebase.updateChildren(InterUpdates);

        voltarActivity();

    }
    public void voltarActivity(){

        CalendarioEventoActivity.super.onBackPressed();
        finish();

    }
}
