package com.thanise.adsp.Activity;

import android.app.ListActivity;

import com.google.firebase.database.Exclude;

import java.util.HashMap;
import java.util.Map;

public class Evento {

    String nomeEvento, dataEvento, horaEvento, notaEvento, id;

    public Evento(){

    }
    public Evento(String nomeEvento, String dataEvento, String horaEvento, String notaEvento, String id){
        this.nomeEvento = nomeEvento;
        this.horaEvento = horaEvento;
        this.notaEvento = notaEvento;
        this.dataEvento = dataEvento;
        this.id = id;
    }
    @Exclude
    public Map<String, Object> toMap() {
        HashMap<String, Object> result = new HashMap<>();
        result.put("nome", nomeEvento);
        result.put("hora", horaEvento);
        result.put("nota", notaEvento);
        result.put("data", dataEvento);
        result.put("id", id);

        return result;
    }

    public String getNomeEvento() {
        return nomeEvento;
    }

    public void setNomeEvento(String nomeEvento) {
        this.nomeEvento = nomeEvento;
    }

    public String getDataEvento() {
        return dataEvento;
    }

    public void setDataEvento(String dataEvento) {
        this.dataEvento = dataEvento;
    }

    public String getHoraEvento() {
        return horaEvento;
    }

    public void setHoraEvento(String horaEvento) {
        this.horaEvento = horaEvento;
    }

    public String getNotaEvento() {
        return notaEvento;
    }

    public void setNotaEvento(String notaEvento) {
        this.notaEvento = notaEvento;
    }
}
