package com.thanise.adsp.Activity;
import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import androidx.appcompat.app.AppCompatActivity;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.thanise.adsp.R;

import java.io.IOException;
import java.util.UUID;

public class BluetoothActivity extends AppCompatActivity {
    BluetoothAdapter meuBluetoothAdapter = null;
    BluetoothDevice meuDevice = null;
    BluetoothSocket meuSocket = null;

    private static final int solicita_bluetooth = 1;
    private static final int solicita_conexao = 2;

    Button conectabluetooth;
    private Button configuracoesbluetooth;
    boolean conexao = false;

    private static String MAC = null;
    UUID meu_uuid = UUID.fromString("00002A05-0000-1000-8000-00805F9B34FB");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bluetooth);

        conectabluetooth = (Button) findViewById(R.id.conectabluetooth);


        meuBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();

        if (meuBluetoothAdapter == null) {
            Toast.makeText(this.getBaseContext(), "Seu dispositivo não tem bluetooth", Toast.LENGTH_LONG).show();
        } else if (!meuBluetoothAdapter.isEnabled()) {
            Intent Solicita_Bluetooth = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
            startActivityForResult(Solicita_Bluetooth, solicita_bluetooth);

        }
        conectabluetooth.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (conexao){
                    //por que isso ta vazio?????
                    //desconectar
                    try{

                    meuSocket.close();
                    conexao = false;
                        conectabluetooth.setText("Conectar");

                        Toast.makeText(getApplicationContext(), "O bluetooth desconectado", Toast.LENGTH_LONG).show();
                    }
                    catch (IOException erro){

                        Toast.makeText(getApplicationContext(), "Ocorreu um ERRO" + erro, Toast.LENGTH_LONG).show();
                    }

                }
                else {
                    //conectar
                    Intent abrelista = new Intent(BluetoothActivity.this, ListaDispositivos.class);
                    startActivityForResult(abrelista, solicita_conexao);
                    //tem algo no design da caixa de dialogo
                }
            }
        });
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data){

        switch (requestCode){
            case solicita_bluetooth: //ver se é aqui que se chama bluetooth ou lista dispositivos. MUDEI BLUETOOTHACTIVITY PARA ACTIVITY.RESULT
                if (resultCode == Activity.RESULT_OK ){
                Toast.makeText(this.getBaseContext(), "Seu dispositivo bluetooth foi ativado", Toast.LENGTH_LONG).show();

            }
            else {
                Toast.makeText(this.getBaseContext(), "O bluetooth, não foi ativado", Toast.LENGTH_LONG).show();
            }
            break;

            case solicita_conexao:
                if (resultCode == Activity.RESULT_OK){

                    MAC = data.getExtras().getString(ListaDispositivos.endereco_mac);

                meuDevice = meuBluetoothAdapter.getRemoteDevice(MAC);
                    //Toast.makeText(this.getBaseContext(), "Final MAC:"+ MAC, Toast.LENGTH_LONG).show();

                    try {
                            meuSocket = meuDevice.createRfcommSocketToServiceRecord(meu_uuid);

                            meuSocket.connect();

                            conexao = true;

                            conectabluetooth.setText("Desconectar");
                        Toast.makeText(this.getApplicationContext(), "Você foi conectado com: " , Toast.LENGTH_LONG).show();

                    } catch (IOException erro){
                        conexao = false;
                        Toast.makeText(this.getApplicationContext(), "Erro ao conectar" + erro, Toast.LENGTH_LONG).show();
                    }
                }
                else {
                    Toast.makeText(this.getApplicationContext(), "Falha em obter o MAC", Toast.LENGTH_LONG).show();
                }
                break;

        }
    }


}

