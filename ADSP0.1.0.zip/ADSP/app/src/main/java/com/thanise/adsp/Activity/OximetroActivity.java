package com.thanise.adsp.Activity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.thanise.adsp.R;

public class OximetroActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_oximetro);
    }
}
