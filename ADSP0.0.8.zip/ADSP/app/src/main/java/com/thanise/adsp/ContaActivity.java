package com.thanise.adsp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class ContaActivity extends AppCompatActivity {
    EditText nomec, telefonec, emailc, senhac;
    TextView nomeC, telefoneC, emailC, senhaC;
    Button botaoe1;
    Button botaoe2;
    Button botaoe3;
    Button botaoe4;

    FirebaseDatabase firebaseDatabase;
    DatabaseReference databaseReference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_conta);
        setTitle("Conta");


        nomec = (EditText) findViewById(R.id.nomec);
        telefonec = (EditText) findViewById(R.id.telefonec);
        emailc = (EditText) findViewById(R.id.emailc);
        senhac = (EditText) findViewById(R.id.senhac);
        botaoe1 = (Button) findViewById(R.id.botaoe1);
        botaoe2 = (Button) findViewById(R.id.botaoe2);
        botaoe3 = (Button) findViewById(R.id.botaoe3);
        botaoe4 = (Button) findViewById(R.id.botaoe1);

        //fazer ações dos botoes e ver o botao de voltar

    }

    private void inicializarFirebase() {
        firebaseDatabase = FirebaseDatabase.getInstance();
        databaseReference = firebaseDatabase.getReference();
    }

}
